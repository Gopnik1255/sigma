﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace Thunder
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private void LoadCpuName()

        {

            try

            {

                string cpuName = GetCpuName();

                cpulabel.Content = cpuName;

            }

            catch (Exception ex)

            {

                cpulabel.Content = "Error retrieving CPU name: " + ex.Message;

            }

        }


        private string GetCpuName()

        {

            string cpuName = string.Empty;

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("select Name from Win32_Processor"))

            {

                foreach (ManagementObject obj in searcher.Get())

                {

                    cpuName = obj["Name"].ToString();

                }

            }

            return cpuName;

        }
        private void LoadGpuName()

        {

            try

            {

                string gpuName = GetGpuName();

                GpuNameLabel.Content = gpuName;

            }

            catch (Exception ex)

            {

                GpuNameLabel.Content = "Error retrieving GPU name: " + ex.Message;

            }

        }
        private void opensigma_MouseDown(object sender, MouseButtonEventArgs e)

        {

            keysys window1 = new keysys();

            window1.Show(); // Opens Window1

        }


        private string GetGpuName()

        {

            string gpuName = string.Empty;

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("select Name from Win32_VideoController"))

            {

                foreach (ManagementObject obj in searcher.Get())

                {

                    gpuName = obj["Name"].ToString();

                }

            }

            return gpuName;

        }
        private void LoadVersion()

        {

            // Get the path to the "version" file in the startup directory

            string startupDirectory = AppDomain.CurrentDomain.BaseDirectory; // Gets the startup directory

            string versionFilePath = Path.Combine(startupDirectory, "version");


            try

            {

                // Read the content of the version file

                string versionText = File.ReadAllText(versionFilePath);

                VersionLabel.Content = versionText; // Update label with file content

            }

            catch (FileNotFoundException)

            {

                VersionLabel.Content = "Version file not found.";

            }

            catch (Exception ex)

            {

                VersionLabel.Content = $"Error: {ex.Message}";

            }

        }


        public Window1()
        {
            InitializeComponent();
            LoadCpuName();
            LoadGpuName();
            LoadVersion();
            session();
        }
        private void DraggableRectangle_MouseDown(object sender, MouseButtonEventArgs e)

        {

            if (e.LeftButton == MouseButtonState.Pressed)

            {

                // Initiate dragging

                this.DragMove();

            }

        }
        private void session()
        {
            string sigma = Environment.UserName;
            semgasir.Content = $"Current session: {sigma}";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
